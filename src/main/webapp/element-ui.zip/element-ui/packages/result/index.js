import Result from './src/index.vue';

/* istanbul ignore next */
Result.install = function(Vue) {
  Vue.component(Result.name, Result);
};

export default Result;
